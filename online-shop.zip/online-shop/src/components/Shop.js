import React, { useState } from "react";
import ItemCard from "./ItemCard";

import Navbar from "./Navbar";

import classes from "../App.module.css";

export default function Shop() {
  const [products, setProducts] = useState([
    {
      id: 1,
      name: "harchi",
      des: "bazam harchi",
      price: 120,
      count: 0,
      availibility: 5,
      src: "https://picsum.photos/seed/picsum/200/300",
    },
    {
      id: 2,
      name: "tyuetrte",
      des: "baztegteam ",
      price: 1200,
      count: 0,
      availibility: 1,
      src: "https://picsum.photos/200/300",
    },
    {
      id: 3,
      name: "harujychi",
      des: " harchi",
      price: 1233300,
      count: 0,
      availibility: 3,
      src: "https://picsum.photos/200/300?grayscale",
    },
    {
      id: 4,
      name: "hahnhi",
      des: "ihiyghj",
      price: 1200,
      count: 0,
      availibility: 4,
      src: "https://picsum.photos/200/300/?blur",
    },
    {
      id: 5,
      name: "tyue",
      des: "bazyjtyuam yugj",
      price: 120330,
      count: 0,
      availibility: 1,
      src: "https://picsum.photos/200/300/?blur=2",
    },
  ]);

  const [selected, setSelected] = useState([]);
  const handleCart = (item) => {
    let itemArgument = { ...item };
    console.log("item argument", item);
    let allProducts = [...products];
    let allSelected = [...selected];
    let isInCart = allSelected.some((mainItem) => {
      return mainItem.id == itemArgument.id;
    });
    if (isInCart) {
      console.log("is in");
      for (let product of allSelected) {
        console.log("product", product);
        if (product.id === item.id) {
          product.availibility--;
          product.count++;
          setSelected(allSelected);
          /* console.log("mojod hast  selected", selected);
          console.log("mojod hast  allselected", allSelected);
          console.log("mojod hast  allproducts", allProducts);
          console.log("mojod hast  products", products); */
        } else {
          console.log("not is in");
          item.availibility--;
          item.count++;
          allSelected.push(item);
          setSelected(allSelected);
          /* console.log("mojod nist  selected", selected);
          console.log("mojod nist  allselected", allSelected);
          console.log("mojod nist  allproducts", allProducts);
          console.log("mojod nist  product", product);
          console.log("mojod nist  products", products); */
        }
      }
    } else {
      console.log("false");
      item.availibility--;
      item.count++;
      allSelected.push(item);
      setSelected(() => {
        return [...allSelected, item];
      });
      setProducts(allProducts);
      console.log("mojod nabode  allselected", allSelected);
      console.log("mojod nabode  allproducts", allProducts);
      console.log("mojod nabode selected", selected);
      console.log("mojod nabode products", products);
    }
  };

  return (
    <>
      <Navbar />
      <div className={classes.products}>
        {products.map((item) => (
          <ItemCard item={item} key={item.id} handleCart={handleCart} />
        ))}
      </div>
    </>
  );
}
